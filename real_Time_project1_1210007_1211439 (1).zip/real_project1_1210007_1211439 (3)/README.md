#Rana Musa 1210007 and Leyan Buirat 1211439
# Tug of war Simulation
This project simulates a Tug of War game using multi-processing in C, where three teams compete by pulling a rope. The simulation uses signals and pipes for inter-process communication (IPC) and visualizes the game using OpenGL.


## Project Structure

The project has the following structure:

```plaintext
Tug of war_simulation/
├── bin/                        # Contains the compiled executable               
├── include/                    # Header files for each module
│   ├── gui.h   
│   └── config.h                # Config module header for loading settings
├── obj/                        # Compiled object files for each source file
├── src/                        # Source code files
│   ├── main.c          # Main file that starts the game & Referee module implementation     
│   ├── player.c                # Player module implementation
│   └── config.c                # Config module implementation to load settings
├── Makefile                    # Makefile for building the project
└── README.md                   # This readme file
```
## Processes and Inter-Process Communication (IPC)

   - Use **pipes** to communicate scores and status between the referee and players, ensuring data is passed along without interfering with process timing.
   - Use **signals** to initiate and synchronize actions between the referee and team players .

## Build and Run

1. **Build the Project**: Run the following command to compile the project and generate the executable:

    ```bash
    make
    ```

2. **Run the Simulation**: Use the following command to run the simulation:

    ```bash
    make run
    ```

3. **Clean Up**: Use the `make clean` command to remove object files and the executable:

    ```bash
    make clean
